from flask import Flask, send_from_directory, jsonify, request
from routes.home import home_bp
from routes.about import about_bp
from routes.passwordgen import passwordgen_bp
from routes.whois import whois_bp
from routes.databreach import databreach_bp
from routes.mac_lookup import mac_lookup_bp
from routes.ip_geolocation import ip_geolocation_bp, init_ip_geolocation_routes  # Import init_ip_geolocation_routes
from routes.ip_blacklist import ip_blacklist_bp, init_ip_blacklist_routes
from flask_limiter import Limiter
from flask_limiter.util import get_remote_address
from modules.outsiders.hackernews import CyberNewsFetcher
from flask_wtf import CSRFProtect
from routes.blogs import blogs_bp
from routes.auth import auth_bp  # Import the auth blueprint
from models import User  # Import your User model
from flask_login import LoginManager
from flask_sitemap import Sitemap
from routes.header_checker import header_checker_bp
from routes.dnslookup import dnslookup_bp
from routes.hashtool import hash_bp
from routes.databreach import init_databreach_routes
import random
import bleach
from flask import render_template_string
import secrets
import base64
from flask import g
import os


app = Flask(__name__)
ext = Sitemap(app=app)




@app.context_processor
def get_quote():
    # Import TeaTimeTips
    from routes.home import TeaTimeTips
    tip_of_the_table = random.choice(TeaTimeTips)
    # Return it as a dictionary to be used in templates
    return {'tip_of_the_table': tip_of_the_table}
    

# Display User IP:
@app.context_processor
def get_ip():
    user_ip = request.remote_addr
    return {'ip': user_ip}



# Dynamically generate the sitemap
@app.route('/sitemap.xml', methods=['GET'])
def sitemap():
    """Generate sitemap.xml."""
    return ext.sitemap()

app.config['SECRET_KEY'] = 'a_hard_to_guess_string'
app.config['SESSION_COOKIE_SECURE'] = True  # Ensures HTTPS only
app.config['SESSION_COOKIE_HTTPONLY'] = True  # Prevents JavaScript access to cookies
app.config['SESSION_COOKIE_SAMESITE'] = 'Lax'  # Prevents CSRF in cross-origin requests
csrf = CSRFProtect(app)


ALLOWED_TAGS = ['p', 'strong', 'em', 'ul', 'li', 'br']

# Example sanitization function for blog summaries
def sanitize_html(content):
    return bleach.clean(content, tags=ALLOWED_TAGS, strip=True)



# Initialize Flask-Login
login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = 'auth.login'  # Specify the login view to redirect when access is denied

# Set up user_loader callback
@login_manager.user_loader
def load_user(user_id):
    return User.get_user_by_id(user_id)


# Initialize the limiter with the app
limiter = Limiter(
    key_func=get_remote_address,
    storage_uri='redis://localhost:6379/0',  # Using localhost
    app=app,
    on_breach=lambda limit: (jsonify({"error": "Too many requests, please try again later."}), 429)
)


# Register the blueprints
app.register_blueprint(home_bp)
app.register_blueprint(about_bp)
app.register_blueprint(passwordgen_bp)
app.register_blueprint(whois_bp)

app.register_blueprint(mac_lookup_bp)
app.register_blueprint(blogs_bp)
app.register_blueprint(auth_bp)  # Register the auth blueprint
app.register_blueprint(hash_bp)
app.register_blueprint(header_checker_bp)
app.register_blueprint(dnslookup_bp)


# Initialize the IP Geolocation routes with the limiter
init_ip_geolocation_routes(limiter)
app.register_blueprint(ip_geolocation_bp)  # Register the blueprint after initializing the routes

init_ip_blacklist_routes(limiter)
app.register_blueprint(ip_blacklist_bp)  # Register the blueprint after initializing the routes

init_databreach_routes(limiter)
app.register_blueprint(databreach_bp)

@app.context_processor
def inject_latest_cyber_news():
    news_fetcher = CyberNewsFetcher()
    news_items = news_fetcher.get_news()
    latest_news = news_items[:10]  # Get the latest 10 news items
    return dict(latest_cyber_news=latest_news)

@app.before_request
def generate_nonce():
    g.csp_nonce = base64.b64encode(os.urandom(16)).decode('utf-8')

@app.after_request
def add_security_headers(response):
    # Apply other security headers globally
    response.headers['X-Content-Type-Options'] = 'nosniff'
    response.headers['X-Frame-Options'] = 'SAMEORIGIN'
    response.headers['Referrer-Policy'] = 'strict-origin-when-cross-origin'
    response.headers['Strict-Transport-Security'] = 'max-age=31536000; includeSubDomains; preload'
    

    # Start with the base strict CSP
    csp = (
        f"default-src 'self'; "
        f"script-src 'self' https://cdn.jsdelivr.net https://cdn.tiny.cloud 'nonce-{g.csp_nonce}'; "
        f"style-src 'self' https://cdn.jsdelivr.net https://use.fontawesome.com https://unpkg.com https://cdn.tiny.cloud; "
        f"font-src 'self' https://use.fontawesome.com https://cdn.tiny.cloud; "
        f"img-src 'self' https://sp.tinymce.com https://blogger.googleusercontent.com data: https://cdn.tiny.cloud; "
        f"object-src 'none'; "
        f"frame-ancestors 'none'; "
        f"form-action 'self'; "
        f"base-uri 'self'; "
        f"upgrade-insecure-requests; "
        f"connect-src 'self' https://cdn.tiny.cloud"
        f"frame-ancestors 'self';"
        f"form-action 'self';"
    )

    # For the /blogs/new page, adjust only the relevant parts of the CSP (style-src)
    if request.path == '/blogs/new' or request.path == request.path.startswith('/blogs/edit/'):
        csp = (
                f"default-src 'self'; "
                f"script-src 'self' https://cdn.jsdelivr.net https://cdn.tiny.cloud 'nonce-{g.csp_nonce}'; "
                f"style-src 'self' 'unsafe-inline' https://cdn.jsdelivr.net https://use.fontawesome.com https://unpkg.com https://cdn.tiny.cloud 'nonce-{g.csp_nonce}'; "  # Allow 'unsafe-inline' only here
                f"font-src 'self' https://use.fontawesome.com https://cdn.tiny.cloud; "
                f"img-src 'self' https://sp.tinymce.com https://blogger.googleusercontent.com data: https://cdn.tiny.cloud; "
                f"object-src 'none'; "
                f"frame-ancestors 'none'; "
                f"form-action 'self'; "
                f"base-uri 'self'; "
                f"upgrade-insecure-requests; "
                f"connect-src 'self' https://cdn.tiny.cloud"
                f"frame-ancestors 'self';"
                f"form-action 'self';"
            )
    elif request.path == '/passwordgen':
        csp = (
                f"default-src 'self'; "
                f"script-src 'self' https://cdn.jsdelivr.net 'nonce-{g.csp_nonce}'; "
                f"style-src 'self' https://cdn.jsdelivr.net https://use.fontawesome.com; "
                f"img-src 'self' https://blogger.googleusercontent.com data: 'nonce-{g.csp_nonce}'; "
                f"font-src 'self' https://use.fontawesome.com; "
                f"connect-src 'self'; "
                f"frame-ancestors 'self';"
                f"form-action 'self';"
            )
    elif request.path == '/password-breach':
        csp = (
            f"default-src 'self'; "
            f"script-src 'self' https://cdn.jsdelivr.net 'nonce-{g.csp_nonce}'; "
            f"style-src 'self' https://cdn.jsdelivr.net https://use.fontawesome.com; "
            f"img-src 'self' data: https://blogger.googleusercontent.com; "
            f"font-src 'self' https://use.fontawesome.com; "
            f"connect-src 'self'; "
            f"frame-ancestors 'self';"
            f"form-action 'self';"
        )
    elif request.path == '/whois':
        csp = (
            f"default-src 'self'; "
            f"script-src 'self' https://cdn.jsdelivr.net 'nonce-{g.csp_nonce}'; "
            f"style-src 'self' https://cdn.jsdelivr.net https://use.fontawesome.com 'nonce-{g.csp_nonce}';"
            f"img-src 'self' data: https://blogger.googleusercontent.com; "
            f"font-src 'self' https://use.fontawesome.com; "
            f"connect-src 'self'; "
            f"frame-ancestors 'self';"
            f"form-action 'self';"
        )
    elif request.path == '/ip-geolocation':
        csp = (
            f"default-src 'self'; "
            f"script-src 'self' https://cdn.jsdelivr.net https://unpkg.com 'nonce-{g.csp_nonce}'; "
            f"style-src 'self' https://unpkg.com https://cdn.jsdelivr.net https://use.fontawesome.com 'nonce-{g.csp_nonce}'; "
            f"img-src 'self' data: https://unpkg.com *.openstreetmap.org  https://blogger.googleusercontent.com; "
            f"font-src 'self' https://use.fontawesome.com https://unpkg.com; "
            f"connect-src 'self'; "
            f"frame-ancestors 'self';"
            f"form-action 'self';"
        )
    elif request.path == '/ip-blacklist':
        csp = (
            f"default-src 'self'; "
            f"script-src 'self' https://cdn.jsdelivr.net https://unpkg.com 'nonce-{g.csp_nonce}'; "
            f"style-src 'self' https://cdn.jsdelivr.net https://use.fontawesome.com 'nonce-{g.csp_nonce}'; "
            f"img-src 'self' data: https://blogger.googleusercontent.com; "
            f"font-src 'self' https://use.fontawesome.com https://unpkg.com; "
            f"connect-src 'self'; "
            f"frame-ancestors 'self';"
            f"form-action 'self';"
        )
    elif request.path == '/fingerprint':
        csp = (
            f"default-src 'self'; "
            f"script-src 'self' https://cdn.jsdelivr.net https://unpkg.com 'nonce-{g.csp_nonce}'; "
            f"style-src 'self' https://cdn.jsdelivr.net https://use.fontawesome.com ; "
            f"img-src 'self' data: https://blogger.googleusercontent.com https://cdn.jsdelivr.net; "
            f"font-src 'self' https://use.fontawesome.com ; "
            f"connect-src 'self'; "
            f"frame-ancestors 'self';"
            f"form-action 'self';"
        )
    elif request.path == '/dns-lookup':
        csp = (
            f"default-src 'self'; "
            f"script-src 'self' https://cdn.jsdelivr.net https://unpkg.com 'nonce-{g.csp_nonce}'; "
            f"style-src 'self' https://cdn.jsdelivr.net https://use.fontawesome.com ; "
            f"img-src 'self' data: https://blogger.googleusercontent.com https://cdn.jsdelivr.net; "
            f"font-src 'self' https://use.fontawesome.com ; "
            f"connect-src 'self'; "
            f"frame-ancestors 'self';"
            f"form-action 'self';"
        )
    elif request.path == '/':
        csp = (
            f"default-src 'self'; "
            f"script-src 'self' https://cdn.jsdelivr.net https://unpkg.com 'nonce-{g.csp_nonce}'; "
            f"style-src 'self' https://cdn.jsdelivr.net https://use.fontawesome.com 'nonce-{g.csp_nonce}'; "
            f"img-src 'self' data: https://blogger.googleusercontent.com https://cdn.jsdelivr.net; "
            f"font-src 'self' https://use.fontawesome.com ; "
            f"connect-src 'self'; "
            f"frame-ancestors 'self';"
            f"form-action 'self';"
        )
        
        
    


    # Apply the CSP header
    response.headers['Content-Security-Policy'] = csp

    return response


# Route to serve robots.txt
@app.route('/robots.txt')
def robots_txt():
    return send_from_directory(app.root_path, 'robots.txt')

@app.errorhandler(500)
def internal_error(error):
    return "An unexpected error occurred. Please try again later.", 500

if __name__ == '__main__':
    app.run(debug=False)
