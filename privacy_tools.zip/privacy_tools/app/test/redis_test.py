import redis
from flask_limiter import Limiter
from flask_limiter.util import get_remote_address
from flask import Flask

app = Flask(__name__)
# Initialize the limiter with the app
limiter = Limiter(
    key_func=get_remote_address,
    storage_uri='redis://localhost:6379/0',  # Using localhost
    app=app,
)

# Test the Redis connection
try:
    test_redis = redis.Redis(host='localhost', port=6379, db=0)
    # Try setting and getting a test value
    test_redis.set('test_key', 'test_value')
    value = test_redis.get('test_key')
    print(f"Redis test connection successful, value retrieved: {value}")
except redis.ConnectionError as e:
    print(f"Redis connection error: {e}")